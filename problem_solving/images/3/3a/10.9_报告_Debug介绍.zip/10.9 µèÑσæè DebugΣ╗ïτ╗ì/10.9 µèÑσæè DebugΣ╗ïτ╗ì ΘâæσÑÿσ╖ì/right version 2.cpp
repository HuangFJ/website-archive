#include <cstdio>
int n, m;
long long factorial(int x)
{
    if(!x) return 1;
    return x * factorial(x-1);
}
int main() {
    scanf("%d%d", &n, &m);
    printf("%lld\n", factorial(n) / factorial(m) / factorial(n-m));
}
#include <iostream>
#include <cmath>
#include <cstdio>
using namespace std;
int n,m,sum[100000000];

int find_it(int L,int R){
    if (L==R) return L;
    double dL = L, dR = R;
    int m1 =((dR-dL+1)/3)+L;
    int m2 =((dR-dL+1)/3)*2+L;
    int t1=sum[m1-1]-sum[L-1],t2=sum[m2-1]-sum[m1-1];
    //printf("Weighing (%d,%d) with (%d,%d):",L,m1-1,m1,m2-1);
    if (t1==t2) {//printf("Same weight, counterfeit in (%d,%d)\n",m2,R);
       return find_it(m2,R);}
    else if (t1<t2) {//printf("Lighter, counterfeit in (%d,%d)\n",L,m1-1);
     return find_it(L,m1-1);}
    else if (t1>t2) {//printf("Heavier, counterfeit in (%d,%d)\n",m1,m2-1);
     return find_it(m1,m2-1);}
    return -1;
}

int main(){
    cout << "Input n and m:\n";
    cin >> n >> m;
    // suppose true coin weighes 2 and fake counterfeit weighes 1
    sum[0]=0;
    for (int i=1;i<=n;i++){
        if (i == m) sum[i]=sum[i-1]+1;
        else sum[i]=sum[i-1]+2;
    }
    cout << "FINDING BEGIN...\n";
    int t=find_it(1,n);
    cout << "The counterfeit is "<<t<<"\n";
    return 0;
}
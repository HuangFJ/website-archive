#include <cstdio>
int n, m;
int factorial(int x)
{
    return x * factorial(x-1);
}
int main() {
    scanf("%d%d", &n, &m);
    printf("%d\n", factorial(n));
}
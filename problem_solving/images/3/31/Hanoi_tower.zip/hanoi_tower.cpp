#include<cstdio>
#include<iostream>
using namespace std;
int dfs(int i1,int i2,int i3,int n){//�������������·����n������i1->i3
    if(n==1)    {
        cout<<"put the 1-th pan from "<<i1<<" to "<<i3<<endl;
        return 1;
    }
	int ans=dfs(i1,i3,i2,n-1);
    cout<<"put the "<<n<<"-th pan from "<<i1<<" to "<<i3<<endl;
    dfs(i2,i1,i3,n-1);
    return ans*2+1;
}
int main() {
    int n;
    cin>>n;
    int ans=dfs(1,2,3,n);
    cout<<"At last there are "<<ans<<" moves."<<endl;
    getchar();
}
